Open index.html. The customer-delivery photo is included. Replace/add vehicle photos later as needed.
